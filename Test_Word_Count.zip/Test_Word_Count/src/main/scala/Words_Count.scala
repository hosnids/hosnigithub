import org.apache.spark.{SparkConf,SparkContext}
object Words_Count {
  def main(args: Array[String]): Unit = {
    val Conf = new SparkConf()
      .setMaster("local")
      .setAppName("Test Spark")
      .set("spark.executor.memory","2g")

    val sc = new SparkContext(Conf)
    val input = sc.textFile("/home/hosni/Desktop/SpringBoot.txt")

    val result_count = input.flatMap(line =>line.split(" "))
      .map(word =>(word,1))
      .reduceByKey(_+_)

    result_count.saveAsTextFile("Output")
    System.out.println("Super The Project Works Fine !!!")

  }

}
